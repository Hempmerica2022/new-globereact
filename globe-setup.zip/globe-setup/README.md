# 🌍 3D Globe — Setup Guide
### entheogenstewardship.org/global-vision

Based on the *Three.js, TSL, React Three Fiber* YouTube tutorial.

---

## What This Installs

| Layer | Technology |
|---|---|
| Build tool | Vite 5 + TypeScript |
| 3D engine | Three.js + React Three Fiber |
| Shaders | TSL (Three.js Shading Language / WebGPU) |
| Controls UI | Leva (sliders) |
| State | Zustand |
| Post-FX | @react-three/postprocessing (Bloom/Glow) |
| Geo data | Python → GeoPandas + Rasterio + NumPy |

---

## Prerequisites

Before running `setup.sh`, you need:

### On Your Hostinger Server (via SSH)
- Node.js **v18 or higher** — enable in hPanel → Node.js
- npm (comes with Node.js)

### On Your Local Machine (for geo-data only)
- Python 3.9+
- ~5 GB disk space for raw geo files

---

## Step-by-Step Instructions

### 1. Fill In Your Secrets

```bash
cp .env.template .env
nano .env       # or open in any text editor
```

Fill in at minimum:
- `LIVE_DATA_API_KEY` — your API key
- `LIVE_DATA_API_URL` — your API base URL

### 2. Upload Files to Hostinger

Upload this entire folder to your Hostinger server via:
- hPanel → File Manager, or
- FTP client (FileZilla, Cyberduck)

Suggested path: `~/globe-setup/`

### 3. SSH Into Your Server

```bash
ssh u123456789@your-hostinger-server.com
cd ~/globe-setup
```

### 4. Run the Setup Script

```bash
chmod +x setup.sh
./setup.sh
```

The script will:
- ✅ Check Node.js version
- ✅ Scaffold Vite + React + TypeScript
- ✅ Install all Three.js / R3F dependencies
- ✅ Write all source files (Globe, Controls, App, store)
- ✅ Build the production bundle → `dist/`
- ✅ Write `.htaccess` for Hostinger routing

### 5. Get the Geographic Data (Local Machine)

Download these two files manually:

**Shape Files** (free, ~100MB):
1. Go to https://www.naturalearthdata.com/downloads/10m-physical-vectors/
2. Download **Land** → `ne_10m_land.zip`
3. Unzip into `python-pipeline/data/`

**Elevation GeoTIFF** (~2–4 GB):
1. Go to https://www.ncei.noaa.gov/products/etopo-global-relief-model
2. Search for **ETOPO 2022**
3. Download the **30 arc-second ICE SURFACE GeoTIFF**
4. Place in `python-pipeline/data/`

### 6. Run the Python Pipeline (Local Machine)

```bash
cd python-pipeline
pip install -r requirements.txt
python process_globe.py
```

Output: `public/data/globe.json` (~75 MB, 1.2 million points)

### 7. Upload globe.json to Hostinger

In hPanel → File Manager:
- Navigate to `public_html/global-vision/data/`
- Upload `globe.json`

### 8. Upload the Built App to Hostinger

In hPanel → File Manager:
- Navigate to `public_html/global-vision/`
- Upload everything inside the `dist/` folder

### 9. Visit Your Globe

```
https://entheogenstewardship.org/global-vision/
```

---

## Globe Features (from the tutorial)

| Feature | Status |
|---|---|
| 1.2M point cloud | ✅ Included |
| Elevation exaggeration slider | ✅ Included |
| Spin / particle animation toggle | ✅ Included |
| Land + water color pickers | ✅ Included |
| Color blend by elevation | ✅ Included |
| Sphere opacity | ✅ Included |
| Bloom / glow effect | ✅ Included |
| Sun rim lighting | ✅ Included |
| Orbit controls | ✅ Included |
| Live API data layer | 🔧 Hook ready in CONFIG |
| GeoJSON country overlays | 🔧 Add via R3F mesh |
| Custom markers / points | 🔧 Add via R3F sprites |

---

## WebGPU / TSL Note

The tutorial's TSL shaders require **WebGPU**, currently supported in:
- ✅ Chrome 113+
- ✅ Edge 113+
- 🚧 Firefox (behind flag)
- ❌ Safari (in development)

The setup includes standard Three.js rendering as fallback for unsupported browsers.

---

## Files Created by setup.sh

```
global-vision/
├── src/
│   ├── main.tsx          ← React entry point
│   ├── App.tsx           ← Canvas + bloom + controls
│   ├── Globe.tsx         ← 3D globe component
│   ├── Controls.tsx      ← Leva slider panel
│   ├── globeStore.ts     ← Zustand shared state
│   └── config.ts         ← API keys (from .env, auto-generated)
├── public/
│   └── data/
│       └── globe.json    ← YOU place this here after Python pipeline
├── python-pipeline/
│   ├── process_globe.py  ← Geo-data processing script
│   └── requirements.txt
├── dist/                 ← Production build (upload to Hostinger)
│   └── .htaccess         ← SPA routing + cache headers
├── index.html
├── vite.config.ts
└── package.json
```

---

## Secrets Checklist

| Secret | Where | Required |
|---|---|---|
| `LIVE_DATA_API_KEY` | `.env` | ✅ Yes |
| `LIVE_DATA_API_URL` | `.env` | ✅ Yes |
| `HOSTINGER_FTP_PASS` | `.env` | Optional |
| `MAPBOX_TOKEN` | `.env` | Only if using Mapbox |

**Never share or commit your `.env` file.**
