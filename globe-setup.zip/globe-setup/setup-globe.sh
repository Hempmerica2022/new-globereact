#!/bin/bash
# ============================================================
#  Three.js 3D Globe — Hostinger Business Hosting Setup
#  Site: entheogenstewardship.org/global-vision
#  Run this on your LOCAL machine (Mac/Linux/WSL on Windows)
# ============================================================

set -e

CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${CYAN}"
echo "  ╔═══════════════════════════════════════════════════╗"
echo "  ║   🌍  Three.js Globe — Hostinger Setup Script     ║"
echo "  ║   entheogenstewardship.org/global-vision          ║"
echo "  ╚═══════════════════════════════════════════════════╝"
echo -e "${NC}"

# ── Step 1: Check prerequisites ─────────────────────────────
echo -e "${CYAN}[1/7] Checking prerequisites...${NC}"

if ! command -v node &> /dev/null; then
  echo -e "${RED}✗ Node.js not found. Install from https://nodejs.org (LTS version)${NC}"
  exit 1
fi
echo -e "${GREEN}✓ Node.js $(node -v) found${NC}"

if ! command -v npm &> /dev/null; then
  echo -e "${RED}✗ npm not found. It comes with Node.js — please reinstall Node.${NC}"
  exit 1
fi
echo -e "${GREEN}✓ npm $(npm -v) found${NC}"

if ! command -v zip &> /dev/null; then
  echo -e "${YELLOW}⚠ zip not found. Installing...${NC}"
  if command -v apt-get &> /dev/null; then
    sudo apt-get install -y zip
  elif command -v brew &> /dev/null; then
    brew install zip
  else
    echo -e "${RED}Please install 'zip' manually then re-run.${NC}"
    exit 1
  fi
fi
echo -e "${GREEN}✓ zip available${NC}"

# ── Step 2: Create project ───────────────────────────────────
echo -e "\n${CYAN}[2/7] Creating project: global-vision${NC}"

PROJECT="global-vision"
if [ -d "$PROJECT" ]; then
  echo -e "${YELLOW}⚠ Folder '$PROJECT' already exists. Remove it first if you want a clean install.${NC}"
else
  mkdir -p "$PROJECT"
fi

cd "$PROJECT"

# ── Step 3: Write .env file ──────────────────────────────────
echo -e "\n${CYAN}[3/7] Creating .env (fill in your secrets here)${NC}"

if [ ! -f ".env" ]; then
cat > .env << 'ENVEOF'
# ============================================================
#  SECRETS — Fill these in locally. Never share this file.
# ============================================================

# OpenWeatherMap API key (free at https://openweathermap.org/api)
VITE_WEATHER_API_KEY=YOUR_OPENWEATHERMAP_KEY_HERE

# Optional: Mapbox token for custom map tiles (https://mapbox.com)
VITE_MAPBOX_TOKEN=YOUR_MAPBOX_TOKEN_HERE

# Optional: AviationStack key for live flight data (https://aviationstack.com)
VITE_AVIATION_API_KEY=YOUR_AVIATIONSTACK_KEY_HERE

# Base path — keep this as /global-vision for Hostinger subdirectory
VITE_BASE_PATH=/global-vision
ENVEOF
  echo -e "${GREEN}✓ .env created — open it and paste your API key(s) before building${NC}"
else
  echo -e "${YELLOW}⚠ .env already exists, skipping.${NC}"
fi

# ── Step 4: Write package.json ───────────────────────────────
echo -e "\n${CYAN}[4/7] Writing package.json${NC}"

cat > package.json << 'EOF'
{
  "name": "global-vision-globe",
  "version": "1.0.0",
  "description": "Three.js 3D Globe for entheogenstewardship.org",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "globe.gl": "^2.31.0",
    "three": "^0.165.0"
  },
  "devDependencies": {
    "vite": "^5.3.0"
  }
}
EOF
echo -e "${GREEN}✓ package.json written${NC}"

# ── Step 5: Write vite.config.js ────────────────────────────
cat > vite.config.js << 'EOF'
import { defineConfig, loadEnv } from 'vite'

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '')
  return {
    base: env.VITE_BASE_PATH || '/global-vision',
    build: {
      outDir: 'dist',
      assetsDir: 'assets',
    }
  }
})
EOF
echo -e "${GREEN}✓ vite.config.js written${NC}"

# ── Step 6: Write the Globe app ──────────────────────────────
echo -e "\n${CYAN}[5/7] Writing globe application files${NC}"

mkdir -p public

# Download Earth texture
echo -e "  → Downloading Earth texture..."
curl -s -o public/earth-texture.jpg \
  "https://raw.githubusercontent.com/vasturiano/globe.gl/master/example/img/earth-blue-marble.jpg" \
  || echo -e "${YELLOW}  ⚠ Could not download texture — using fallback color${NC}"

# Download GeoJSON country borders
echo -e "  → Downloading country GeoJSON..."
curl -s -o public/countries.geojson \
  "https://raw.githubusercontent.com/vasturiano/globe.gl/master/example/world-geo-json/countries.geojson" \
  || echo -e "${YELLOW}  ⚠ Could not download GeoJSON — borders will be skipped${NC}"

# Write index.html
cat > index.html << 'HTMLEOF'
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Global Vision | Entheogen Stewardship</title>
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      background: #020a18;
      color: #e0f0ff;
      font-family: 'Courier New', monospace;
      overflow: hidden;
      height: 100vh;
      width: 100vw;
    }

    #globe-container {
      position: fixed;
      inset: 0;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    #ui-overlay {
      position: fixed;
      top: 0; left: 0;
      width: 100%;
      pointer-events: none;
      z-index: 10;
      padding: 2rem;
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
    }

    .title-block h1 {
      font-size: clamp(1rem, 3vw, 1.6rem);
      letter-spacing: 0.3em;
      text-transform: uppercase;
      color: #88d8ff;
      text-shadow: 0 0 20px #88d8ff88;
    }
    .title-block p {
      font-size: 0.7rem;
      letter-spacing: 0.2em;
      color: #4a8ab0;
      margin-top: 0.3rem;
    }

    #weather-panel {
      background: rgba(2, 15, 35, 0.75);
      border: 1px solid #1a4060;
      border-radius: 6px;
      padding: 0.8rem 1.2rem;
      font-size: 0.72rem;
      color: #88d8ff;
      min-width: 180px;
      backdrop-filter: blur(8px);
      line-height: 1.8;
    }

    #weather-panel .label { color: #4a8ab0; font-size: 0.62rem; letter-spacing: 0.15em; }

    #tooltip {
      position: fixed;
      background: rgba(2, 15, 35, 0.9);
      border: 1px solid #1a6080;
      border-radius: 4px;
      padding: 0.5rem 0.8rem;
      font-size: 0.72rem;
      color: #88d8ff;
      pointer-events: none;
      display: none;
      z-index: 20;
      backdrop-filter: blur(6px);
    }

    #bottom-bar {
      position: fixed;
      bottom: 1.5rem;
      left: 50%;
      transform: translateX(-50%);
      font-size: 0.65rem;
      letter-spacing: 0.2em;
      color: #2a5070;
      z-index: 10;
    }

    .pulse-ring {
      animation: pulse 2s ease-in-out infinite;
    }
    @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }
  </style>
</head>
<body>

<div id="globe-container"></div>

<div id="ui-overlay">
  <div class="title-block">
    <h1>Global Vision</h1>
    <p>Entheogen Stewardship Network</p>
  </div>
  <div id="weather-panel">
    <div class="label">LIVE CONDITIONS</div>
    <div id="weather-content">Loading...</div>
  </div>
</div>

<div id="tooltip"></div>
<div id="bottom-bar">ENTHEOGENSTEWARDSHIP.ORG &nbsp;·&nbsp; GLOBAL VISION</div>

<script type="module" src="/src/main.js"></script>
</body>
</html>
HTMLEOF

# Write main JS
mkdir -p src
cat > src/main.js << 'JSEOF'
import Globe from 'globe.gl'

const WEATHER_KEY = import.meta.env.VITE_WEATHER_API_KEY || ''
const BASE = import.meta.env.BASE_URL || '/global-vision/'

// ── Custom marker locations ────────────────────────────────
// Add or edit your own points of interest here
const CUSTOM_MARKERS = [
  { lat: 37.77, lng: -122.41, name: 'San Francisco', note: 'West Coast Hub', color: '#00ffcc' },
  { lat: 51.50, lng: -0.12,   name: 'London',        note: 'European Network', color: '#00ffcc' },
  { lat: 35.68, lng: 139.69,  name: 'Tokyo',         note: 'Asia Pacific', color: '#00ffcc' },
  { lat: -33.86, lng: 151.20, name: 'Sydney',        note: 'Oceania Node', color: '#00ffcc' },
  { lat: -23.54, lng: -46.63, name: 'São Paulo',     note: 'South America', color: '#00ffcc' },
  // ── Add your own markers below ──
  // { lat: YOUR_LAT, lng: YOUR_LNG, name: 'Label', note: 'Description', color: '#00ffcc' },
]

// ── Init Globe ─────────────────────────────────────────────
const container = document.getElementById('globe-container')
const W = window.innerWidth
const H = window.innerHeight

const globe = Globe()(container)
  .width(W)
  .height(H)
  .backgroundColor('rgba(0,0,0,0)')
  .globeImageUrl(`${BASE}earth-texture.jpg`)
  .atmosphereColor('#1a6080')
  .atmosphereAltitude(0.18)

// ── GeoJSON country borders ────────────────────────────────
fetch(`${BASE}countries.geojson`)
  .then(r => r.json())
  .then(data => {
    globe
      .polygonsData(data.features)
      .polygonCapColor(() => 'rgba(0,0,0,0)')
      .polygonSideColor(() => 'rgba(20,80,120,0.15)')
      .polygonStrokeColor(() => '#1a4060')
      .polygonAltitude(0.001)
  })
  .catch(() => console.warn('GeoJSON not loaded'))

// ── Custom markers ─────────────────────────────────────────
const tooltip = document.getElementById('tooltip')

globe
  .pointsData(CUSTOM_MARKERS)
  .pointLat('lat')
  .pointLng('lng')
  .pointColor('color')
  .pointAltitude(0.02)
  .pointRadius(0.4)
  .pointLabel(d => `<b>${d.name}</b><br><small>${d.note}</small>`)
  .onPointHover((point, ev) => {
    if (point) {
      tooltip.style.display = 'block'
      tooltip.innerHTML = `<strong>${point.name}</strong><br>${point.note}`
    } else {
      tooltip.style.display = 'none'
    }
  })

document.addEventListener('mousemove', e => {
  tooltip.style.left = (e.clientX + 14) + 'px'
  tooltip.style.top  = (e.clientY + 14) + 'px'
})

// ── Auto-rotate ────────────────────────────────────────────
globe.controls().autoRotate = true
globe.controls().autoRotateSpeed = 0.5

// ── Resize handler ─────────────────────────────────────────
window.addEventListener('resize', () => {
  globe.width(window.innerWidth).height(window.innerHeight)
})

// ── Live weather (OpenWeatherMap) ──────────────────────────
async function fetchWeather () {
  const panel = document.getElementById('weather-content')
  if (!WEATHER_KEY || WEATHER_KEY === 'YOUR_OPENWEATHERMAP_KEY_HERE') {
    panel.innerHTML = '<span style="color:#4a8ab0">Add API key to .env<br>to enable live data</span>'
    return
  }

  // Fetch weather for a default city — change to suit your needs
  const CITY = 'New York'
  try {
    const res  = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?q=${CITY}&appid=${WEATHER_KEY}&units=imperial`
    )
    const data = await res.json()
    if (data.cod !== 200) throw new Error(data.message)
    panel.innerHTML = `
      <div><span class="label">CITY &nbsp;</span>${data.name}, ${data.sys.country}</div>
      <div><span class="label">TEMP &nbsp;</span>${Math.round(data.main.temp)}°F</div>
      <div><span class="label">SKY &nbsp;&nbsp;</span>${data.weather[0].description}</div>
      <div><span class="label">WIND &nbsp;</span>${Math.round(data.wind.speed)}