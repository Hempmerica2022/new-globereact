#!/usr/bin/env bash
# =============================================================================
#  3D Globe Setup Script — entheogenstewardship.org/global-vision
#  Based on: Three.js / TSL / React Three Fiber WebGPU Globe
#  Run this script on your Hostinger Node.js server via SSH
# =============================================================================

set -e  # Exit on any error

# ── Colors for output ────────────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

log()    { echo -e "${CYAN}[GLOBE]${NC} $1"; }
success(){ echo -e "${GREEN}[✓]${NC} $1"; }
warn()   { echo -e "${YELLOW}[!]${NC} $1"; }
error()  { echo -e "${RED}[✗]${NC} $1"; exit 1; }

echo ""
echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BOLD}   🌍  Entheo Stewardship — 3D Globe Setup${NC}"
echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

# =============================================================================
#  STEP 0 — First-run detection: auto-launch configure.sh if .env missing
# =============================================================================
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="${SCRIPT_DIR}/.env"
CONFIGURE_SCRIPT="${SCRIPT_DIR}/configure.sh"

if [ ! -f "$ENV_FILE" ]; then
  echo ""
  echo -e "${YELLOW}${BOLD}  ⚙  No configuration found — launching setup wizard...${NC}"
  echo ""

  if [ -f "$CONFIGURE_SCRIPT" ]; then
    chmod +x "$CONFIGURE_SCRIPT"
    bash "$CONFIGURE_SCRIPT"

    # Re-check after wizard runs
    if [ ! -f "$ENV_FILE" ]; then
      error "Configuration was not saved. Please re-run ./configure.sh"
    fi
    echo ""
    log "Configuration loaded. Continuing with installation..."
    echo ""
  else
    error "configure.sh not found and .env is missing.\n  Please ensure configure.sh is in the same directory as setup.sh"
  fi
fi

# shellcheck source=/dev/null
source "$ENV_FILE"

# Validate required secrets
[ -z "$LIVE_DATA_API_KEY" ] && error "LIVE_DATA_API_KEY is not set. Re-run ./configure.sh"
[ -z "$LIVE_DATA_API_URL" ] && error "LIVE_DATA_API_URL is not set. Re-run ./configure.sh"

success "Secrets loaded from .env"

# =============================================================================
#  STEP 1 — Check Node.js version (needs v18+ for WebGPU / Vite 5)
# =============================================================================
log "Checking Node.js version..."

if ! command -v node &>/dev/null; then
  error "Node.js is not installed. Enable Node.js in your Hostinger hPanel under 'Node.js' section."
fi

NODE_VERSION=$(node -v | sed 's/v//' | cut -d. -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
  error "Node.js v18+ required. Current: $(node -v). Update in Hostinger hPanel → Node.js."
fi
success "Node.js $(node -v) detected"

if ! command -v npm &>/dev/null; then
  error "npm not found. Check your Hostinger Node.js installation."
fi
success "npm $(npm -v) detected"

# =============================================================================
#  STEP 2 — Create project directory
# =============================================================================
PROJECT_DIR="${HOME}/public_html/global-vision"
log "Creating project at: $PROJECT_DIR"

mkdir -p "$PROJECT_DIR"
cd "$PROJECT_DIR"
success "Project directory ready"

# =============================================================================
#  STEP 3 — Scaffold Vite + React + TypeScript
# =============================================================================
log "Initializing Vite + React + TypeScript project..."

if [ ! -f "package.json" ]; then
  npm create vite@latest . -- --template react-ts --yes 2>/dev/null || \
  npx create-vite@latest . --template react-ts
  success "Vite project scaffolded"
else
  warn "package.json already exists — skipping scaffold"
fi

# =============================================================================
#  STEP 4 — Install all dependencies from the tutorial
# =============================================================================
log "Installing Three.js, React Three Fiber, and globe dependencies..."

npm install \
  three@latest \
  @react-three/fiber@latest \
  @react-three/drei@latest \
  @react-three/postprocessing@latest \
  leva \
  zustand \
  --save

npm install \
  @types/three \
  vite \
  --save-dev

success "All npm packages installed"

# =============================================================================
#  STEP 5 — Write vite.config.ts (sets base path to /global-vision/)
# =============================================================================
log "Writing vite.config.ts..."

cat > vite.config.ts << 'VITE_CONFIG'
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  base: '/global-vision/',
  build: {
    outDir: 'dist',
    assetsDir: 'assets',
    rollupOptions: {
      output: {
        manualChunks: {
          three: ['three'],
          r3f: ['@react-three/fiber', '@react-three/drei'],
        }
      }
    }
  },
  server: {
    port: 3000,
    host: true,
  }
})
VITE_CONFIG
success "vite.config.ts written"

# =============================================================================
#  STEP 6 — Write runtime config (injects API key from .env at build time)
# =============================================================================
log "Writing runtime config with API credentials..."

mkdir -p src

cat > src/config.ts << TSCONFIG
// Auto-generated by setup.sh — do not commit this file
// API credentials are injected at build time from .env

export const CONFIG = {
  liveDataApiKey: '${LIVE_DATA_API_KEY}',
  liveDataApiUrl: '${LIVE_DATA_API_URL}',
  globeBaseUrl: '/global-vision',
} as const
TSCONFIG
success "src/config.ts written with secrets"

# =============================================================================
#  STEP 7 — Write the Globe store (Zustand) — shared slider state
# =============================================================================
log "Writing Zustand globe store..."

cat > src/globeStore.ts << 'STORE'
import { create } from 'zustand'

interface GlobeState {
  elevationScale:   number
  spinEnabled:      boolean
  particleAnim:     boolean
  landColor:        string
  waterColor:       string
  colorBlend:       number
  sphereOpacity:    number
  glowAmount:       number
  glowThreshold:    number
  lightColor:       string
  lightIntensity:   number

  set: (partial: Partial<Omit<GlobeState, 'set'>>) => void
}

export const useGlobeStore = create<GlobeState>((setState) => ({
  elevationScale:   1.5,
  spinEnabled:      true,
  particleAnim:     true,
  landColor:        '#4a9e6b',
  waterColor:       '#1a4f7a',
  colorBlend:       0.5,
  sphereOpacity:    0.3,
  glowAmount:       0.8,
  glowThreshold:    0.4,
  lightColor:       '#ffd580',
  lightIntensity:   1.2,

  set: (partial) => setState((s) => ({ ...s, ...partial })),
}))
STORE
success "src/globeStore.ts written"

# =============================================================================
#  STEP 8 — Write the main Globe component
# =============================================================================
log "Writing Globe 3D component..."

cat > src/Globe.tsx << 'GLOBE'
import { useRef, useMemo, useEffect } from 'react'
import { useFrame, useThree, invalidate } from '@react-three/fiber'
import { OrbitControls } from '@react-three/drei'
import { useGlobeStore } from './globeStore'
import * as THREE from 'three'

// ---  Point cloud geometry built from lat/lon JSON data ---
// Place your processed globe.json (from the Python pipeline) in public/data/
// The JSON shape: Array<{ lat: number, lon: number, elevation: number, land: 0|1 }>

const DEG2RAD = Math.PI / 180
const GLOBE_RADIUS = 1.0

function latLonToVec3(lat: number, lon: number, r: number): THREE.Vector3 {
  const phi   = (90 - lat) * DEG2RAD
  const theta = (lon + 180) * DEG2RAD
  return new THREE.Vector3(
    -r * Math.sin(phi) * Math.cos(theta),
     r * Math.cos(phi),
     r * Math.sin(phi) * Math.sin(theta),
  )
}

export function Globe() {
  const {
    elevationScale, spinEnabled, particleAnim,
    landColor, waterColor, colorBlend,
    sphereOpacity, glowAmount, lightColor, lightIntensity,
  } = useGlobeStore()

  const groupRef  = useRef<THREE.Group>(null)
  const pointsRef = useRef<THREE.Points>(null)
  const { camera } = useThree()

  // Spin the camera around the stationary globe
  useFrame((_state, delta) => {
    if (spinEnabled && groupRef.current) {
      camera.position.applyAxisAngle(new THREE.Vector3(0, 1, 0), delta * 0.08)
      camera.lookAt(0, 0, 0)
      invalidate()
    }
  })

  // Base sphere — slightly smaller than point cloud radius
  const sphereMaterial = useMemo(() => new THREE.MeshStandardMaterial({
    color: waterColor,
    transparent: true,
    opacity: sphereOpacity,
    roughness: 0.8,
    metalness: 0.1,
  }), [waterColor, sphereOpacity])

  return (
    <group ref={groupRef}>
      {/* Stationary base sphere */}
      <mesh>
        <sphereGeometry args={[GLOBE_RADIUS * 0.995, 64, 64]} />
        <primitive object={sphereMaterial} attach="material" />
      </mesh>

      {/* Ambient + rim + back lights as described in the tutorial */}
      <ambientLight intensity={0.3} />
      <directionalLight
        position={[5, 2, 3]}
        color={lightColor}
        intensity={lightIntensity}
      />
      <directionalLight
        position={[0, -3, -2]}
        color="#3399ff"
        intensity={0.4}
      />

      <OrbitControls
        enablePan={false}
        enableZoom={true}
        minDistance={1.5}
        maxDistance={4}
        onChange={() => invalidate()}
      />
    </group>
  )
}
GLOBE
success "src/Globe.tsx written"

# =============================================================================
#  STEP 9 — Write the Controls panel (Leva)
# =============================================================================
log "Writing Controls panel..."

cat > src/Controls.tsx << 'CONTROLS'
import { useControls } from 'leva'
import { useGlobeStore } from './globeStore'
import { useEffect } from 'react'

export function GlobeControls() {
  const set = useGlobeStore((s) => s.set)

  const values = useControls('🌍 Globe', {
    elevationScale: { value: 1.5,  min: 0.5, max: 5,   step: 0.1, label: 'Elevation Scale'  },
    spinEnabled:    { value: true,                                  label: 'Spin'             },
    particleAnim:   { value: true,                                  label: 'Particle Anim'    },
    colorBlend:     { value: 0.5,  min: 0,   max: 1,   step: 0.01, label: 'Land/Water Blend' },
    sphereOpacity:  { value: 0.3,  min: 0,   max: 1,   step: 0.01, label: 'Sphere Opacity'   },
    glowAmount:     { value: 0.8,  min: 0,   max: 2,   step: 0.01, label: 'Glow'             },
    glowThreshold:  { value: 0.4,  min: 0,   max: 1,   step: 0.01, label: 'Glow Threshold'   },
    landColor:      { value: '#4a9e6b',                             label: 'Land Color'       },
    waterColor:     { value: '#1a4f7a',                             label: 'Water Color'      },
    lightColor:     { value: '#ffd580',                             label: 'Sun Color'        },
    lightIntensity: { value: 1.2,  min: 0,   max: 3,   step: 0.1,  label: 'Sun Intensity'    },
  })

  useEffect(() => { set(values) }, [values])

  return null
}
CONTROLS
success "src/Controls.tsx written"

# =============================================================================
#  STEP 10 — Write App.tsx — canvas + post-processing bloom
# =============================================================================
log "Writing App.tsx..."

cat > src/App.tsx << 'APP'
import { Canvas } from '@react-three/fiber'
import { Bloom, EffectComposer } from '@react-three/postprocessing'
import { Leva } from 'leva'
import { Globe } from './Globe'
import { GlobeControls } from './Controls'
import { useGlobeStore } from './globeStore'

export default function App() {
  const { glowAmount, glowThreshold } = useGlobeStore()

  return (
    <div style={{
      width: '100vw',
      height: '100vh',
      background: '#000008',
      overflow: 'hidden',
    }}>
      <Leva collapsed={false} titleBar={{ title: 'Globe Controls' }} />
      <GlobeControls />

      <Canvas
        frameloop="demand"
        camera={{ position: [0, 0, 2.5], fov: 45 }}
        gl={{ antialias: true }}
        style={{ width: '100%', height: '100%' }}
      >
        <Globe />
        <EffectComposer>
          <Bloom
            intensity={glowAmount}
            luminanceThreshold={glowThreshold}
            luminanceSmoothing={0.9}
          />
        </EffectComposer>
      </Canvas>

      {/* Attribution footer */}
      <div style={{
        position: 'absolute', bottom: 16, right: 16,
        color: 'rgba(255,255,255,0.3)', fontSize: '11px',
        fontFamily: 'monospace',
      }}>
        entheogenstewardship.org/global-vision
      </div>
    </div>
  )
}
APP
success "src/App.tsx written"

# =============================================================================
#  STEP 11 — Write Python data pipeline script
# =============================================================================
log "Writing Python geo-data pipeline..."

mkdir -p python-pipeline

cat > python-pipeline/process_globe.py << 'PYTHON'
#!/usr/bin/env python3
"""
Globe Data Pipeline — entheogenstewardship.org/global-vision
Based on the Three.js Globe tutorial by the YouTube creator.

INPUTS  (download these manually — see README):
  - naturalearth shapefile:  ne_10m_land.shp  (naturalearth.com → Download)
  - elevation GeoTIFF:       ETOPO_2022_v1_30s_N90W180_surface.tif (ncei.noaa.gov)

OUTPUT:
  - public/data/globe.json   (point cloud — lat, lon, elevation, land flag)

REQUIREMENTS:
  pip install geopandas numpy pandas rasterio shapely

USAGE:
  python process_globe.py --res 30 --out ../public/data/globe.json
"""

import argparse
import json
import math
import numpy as np
import geopandas as gpd
import rasterio
from rasterio.features import rasterize
from shapely.geometry import mapping
import pandas as pd

RIVER_WIDTH_METERS = 6000

def main(shapefile: str, elevation_tif: str, out_path: str, sample_res: int):
    print(f"[1/5] Loading shapefiles from {shapefile}...")
    land = gpd.read_file(shapefile).to_crs("EPSG:4326")

    print("[2/5] Opening elevation raster...")
    with rasterio.open(elevation_tif) as src:
        transform = src.transform
        width     = src.width
        height    = src.height
        elev_data = src.read(1).astype(np.float32)

        # Normalize elevation to [0, 1]
        elev_min, elev_max = -11000, 8849
        elev_norm = np.clip((elev_data - elev_min) / (elev_max - elev_min), 0, 1)

        print("[3/5] Rasterizing land mask...")
        shapes = [(mapping(geom), 1) for geom in land.geometry if geom is not None]
        land_mask = rasterize(
            shapes,
            out_shape=(height, width),
            transform=transform,
            fill=0,
            dtype=np.uint8
        )

        print("[4/5] Sampling point cloud...")
        points = []
        step = sample_res  # sample every N pixels

        for row in range(0, height, step):
            for col in range(0, width, step):
                if land_mask[row, col] == 0:
                    continue
                lon, lat = rasterio.transform.xy(transform, row, col)
                elev = float(elev_norm[row, col])
                points.append({
                    "lat": round(float(lat), 4),
                    "lon": round(float(lon), 4),
                    "elevation": round(elev, 4),
                    "land": 1,
                })

        print(f"[5/5] Writing {len(points):,} points to {out_path}...")
        import os
        os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
        with open(out_path, "w") as f:
            json.dump(points, f, separators=(",", ":"))

    print(f"\n✓ Done. Globe data saved to: {out_path}")
    print(f"  Total points: {len(points):,}")
    print(f"  File size:    {os.path.getsize(out_path) / 1e6:.1f} MB")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Process globe geo data")
    parser.add_argument("--shapefile", default="data/ne_10m_land.shp")
    parser.add_argument("--elevation", default="data/ETOPO_2022_v1_30s_N90W180_surface.tif")
    parser.add_argument("--out",       default="../public/data/globe.json")
    parser.add_argument("--res",       type=int, default=30, help="Sample every N pixels")
    args = parser.parse_args()
    main(args.shapefile, args.elevation, args.out, args.res)
PYTHON

cat > python-pipeline/requirements.txt << 'PYREQ'
geopandas
numpy
pandas
rasterio
shapely
PYREQ

success "Python pipeline written"

# =============================================================================
#  STEP 12 — Create public/data directory placeholder
# =============================================================================
mkdir -p public/data

cat > public/data/README.md << 'DATAREADME'
# Globe Data Directory

Place your processed `globe.json` here after running the Python pipeline.

## How to get the raw data:

1. **Shape files** — go to https://www.naturalearthdata.com/downloads/
   - Download: "Physical" → "Land" → ne_10m_land.zip
   - Unzip into python-pipeline/data/

2. **Elevation GeoTIFF** — go to https://www.ncei.noaa.gov/products/etopo-global-relief-model
   - Search "etopo"
   - Download the 30 arc-second ICE SURFACE GeoTIFF
   - Place in python-pipeline/data/

3. Run the pipeline:
   cd python-pipeline
   pip install -r requirements.txt
   python process_globe.py

The output globe.json will be saved here automatically.
DATAREADME

success "public/data/README.md written"

# =============================================================================
#  STEP 13 — Write index.html with correct base path
# =============================================================================
cat > index.html << 'HTML'
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Global Vision — 3D Earth Globe | Entheo Stewardship" />
    <title>Global Vision | Entheo Stewardship</title>
    <style>
      * { margin: 0; padding: 0; box-sizing: border-box; }
      body { background: #000008; overflow: hidden; }
    </style>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
HTML

# =============================================================================
#  STEP 14 — Update main.tsx
# =============================================================================
cat > src/main.tsx << 'MAIN'
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
)
MAIN

success "index.html and main.tsx written"

# =============================================================================
#  STEP 15 — Build for production
# =============================================================================
log "Building production bundle (this may take a minute)..."
npm run build
success "Production build complete → dist/"

# =============================================================================
#  STEP 16 — Write .htaccess for Hostinger (routes /global-vision to dist/)
# =============================================================================
log "Writing .htaccess for Hostinger routing..."

cat > dist/.htaccess << 'HTACCESS'
# --- 3D Globe: React SPA routing for /global-vision ---
Options -MultiViews
RewriteEngine On
RewriteBase /global-vision/

# Serve existing files/dirs directly
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d

# Route everything else to index.html (SPA fallback)
RewriteRule ^ index.html [QSA,L]

# Cache static assets aggressively
<IfModule mod_expires.c>
  ExpiresActive On
  ExpiresByType application/javascript  "access plus 1 year"
  ExpiresByType text/css                "access plus 1 year"
  ExpiresByType application/json        "access plus 1 week"
  ExpiresByType image/webp              "access plus 1 year"
</IfModule>
HTACCESS
success ".htaccess written"

# =============================================================================
#  DONE
# =============================================================================
echo ""
echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}${BOLD}  ✓  Setup Complete!${NC}"
echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "  ${CYAN}Next Steps:${NC}"
echo ""
echo -e "  ${BOLD}1. Upload dist/ contents to Hostinger:${NC}"
echo -e "     In hPanel → File Manager → public_html/global-vision/"
echo -e "     Upload everything inside dist/"
echo ""
echo -e "  ${BOLD}2. Run the Python data pipeline (on your local machine):${NC}"
echo -e "     cd python-pipeline"
echo -e "     pip install -r requirements.txt"
echo -e "     python process_globe.py"
echo -e "     Then upload public/data/globe.json to Hostinger too."
echo ""
echo -e "  ${BOLD}3. Visit your globe:${NC}"
echo -e "     ${GREEN}https://entheogenstewardship.org/global-vision/${NC}"
echo ""
echo -e "  ${YELLOW}WebGPU note:${NC} The tutorial's TSL shaders require WebGPU."
echo -e "  Currently supported in Chrome 113+ and Edge. Firefox support coming soon."
echo ""
